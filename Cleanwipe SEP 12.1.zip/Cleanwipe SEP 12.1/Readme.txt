About CleanWipe
===============

CleanWipe is a tool that you can use to prepare or clean any supported Windows computer before you install Symantec Endpoint Protection. It is a self-extracting executable that unzips its batch files, utility programs, and data files to the Windows\Temp folder by default.

Use CleanWipe with caution. You should use CleanWipe as a last resort after all other means to prepare or clean a computer for Symantec Endpoint Protection installation have failed.  

Running CleanWipe may result in MsiInstaller items being logged in the Windows Event Viewer Application log with the following descriptive text: 

"Failed to connect to server. Error 0x800401F0."
 
These Event Viewer log entries are harmless and can be ignored.

In rare situations, running CleanWipe may cause a computer to crash with a blue screen. If this occurs, restart the computer and run CleanWipe again to solve the problem.


Running CleanWipe 
=================

To run CleanWipe on 32-bit operating systems:
---------------------------------------------
1. Copy the CleanWipe folder to the target computer.

2. Open the CleanWipe folder and double-click the CleanWipe.exe file.

3. When you are prompted, browse to a location where you want the files to be copied and then click Start to extract the files.  

If you click Start without selecting a location, the files are extracted to the Windows\Temp folder.

4. When you are asked if you want to run CleanWipe now, click Yes to run CleanWipe immediately; click no to run CleanWipe later. 

5. As you run CleanWipe, you are prompted several times. It is recommended that you click Yes in response to all prompts.   

If you choose to run CleanWipe later, browse to the CleanWipe\app folder and double-click the RunCleanWipe.bat batch file. Remember to click Yes in response to all prompts.


To run CleanWipe on 64-bit operating systems:
---------------------------------------------
1. Copy the CleanWipe folder to the target computer.

2. Open a command prompt and change directories to the CleanWipe folder. Type CleanWipe.exe and press Enter.

3. When you are prompted, browse to a location where you want the files to be copied and then click Start to extract the files.  

If you click Start without selecting a location, the files are extracted to the Windows\Temp folder.

4. CleanWipe cannot automatically launch after you extract it on 64-bit operating systems, so change directory to the CleanWipe\app folder and double-click the RunCleanWipe.bat batch file.

Remember to click Yes in response to all prompts.


To run CleanWipe in silent mode:
--------------------------------
1. Copy the CleanWipe folder to the target computer.

2. Open the CleanWipe folder and double-click the CleanWipe.exe file.

3. When you are prompted, browse to a location where you want the files to be copied and then click Start to extract the files.  

If you click Start without selecting a location, the files are extracted to the Windows\Temp folder.

4. If you are asked if you want to run CleanWipe now, click No. 

5. Open a command prompt and change directory to the CleanWipe\app folder.

6. Type the following command: 

RunCleanWipe -silent

7. CleanWipe then uses its defaults to run without any user input.


Note: When running CleanWipe On the Microsoft Vista operating system you must run as administrator.

